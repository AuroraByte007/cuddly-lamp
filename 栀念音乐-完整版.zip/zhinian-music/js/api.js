/* api.js —— 线上音源层：通道定义、曲库、官方嵌入地址拼装
 * 只做地址拼装与通道状态，不发任何音频直链请求
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};

  /* 5 个直通通道：两路网易云 + SoundCloud 单曲/歌单 + 自定义嵌入 */
  var CHANNELS = [
    { id: 'A', name: '网易云·单曲', kind: '163', need: '' },
    { id: 'B', name: '网易云·歌单', kind: '163pl', need: '歌单 ID' },
    { id: 'C', name: 'SoundCloud·单曲', kind: 'sc', need: '曲目链接' },
    { id: 'D', name: 'SoundCloud·歌单', kind: 'scpl', need: '歌单链接' },
    { id: 'E', name: '自定义嵌入', kind: 'custom', need: 'https 地址' }
  ];

  /* VIP 歌手名单：非 VIP 用户最多听到总时长 1/3 */
  var VIP_ARTISTS = ['周杰伦', '邓紫棋', '林俊杰', '周深', '陈奕迅', 'Beyond', '黄家驹', '薛之谦', '王心凌'];

  /* 曲库：网易云公开元数据，封面为网络图，vip=1 标记受 1/3 限制 */
  var TRACKS = [
    {"id": "1357375695", "name": "海阔天空", "artist": "Beyond", "dur": 239560, "pic": "https://p1.music.126.net/q6cm6Pk70YArijk1_QDoEg==/109951163984013003.jpg", "lang": "yue", "vip": 1},
    {"id": "346576", "name": "光辉岁月", "artist": "Beyond", "dur": 298560, "pic": "https://p1.music.126.net/JOJvZc_7SqQjKf8TktQ_bw==/29686813951246.jpg", "lang": "yue", "vip": 1},
    {"id": "32701152", "name": "灰色轨迹", "artist": "Beyond", "dur": 324986, "pic": "https://p1.music.126.net/K_p-jhEvCpP7I4Sqd_QfFw==/7954966627607511.jpg", "lang": "yue", "vip": 1},
    {"id": "346073", "name": "喜欢你", "artist": "Beyond", "dur": 274573, "pic": "https://p1.music.126.net/zZtUDuWk6qIe3ezMt4UMjg==/109951165796417308.jpg", "lang": "yue", "vip": 1},
    {"id": "1385227380", "name": "起风了", "artist": "吴青峰", "dur": 313565, "pic": "https://p1.music.126.net/t9FzacVQw6CC-P1-X5Pquw==/109951164308230490.jpg", "lang": "zh", "vip": 0},
    {"id": "28815250", "name": "平凡之路", "artist": "朴树", "dur": 302119, "pic": "https://p1.music.126.net/W_5XiCv3rGS1-J7EXpHSCQ==/18885211718782327.jpg", "lang": "zh", "vip": 0},
    {"id": "254574", "name": "后来", "artist": "刘若英", "dur": 341400, "pic": "https://p1.music.126.net/eBF7bHnJYBUfOFrJ_7SUfw==/109951163351825356.jpg", "lang": "zh", "vip": 0},
    {"id": "25706282", "name": "夜空中最亮的星", "artist": "逃跑计划", "dur": 252235, "pic": "https://p1.music.126.net/625-tE8OzdM-rWO37PgqlQ==/109951168111472442.jpg", "lang": "zh", "vip": 0},
    {"id": "1430319727", "name": "漠河舞厅", "artist": "柳爽", "dur": 334240, "pic": "https://p1.music.126.net/BMPeBg8b6wRUofmMcfQ--g==/109951165029361219.jpg", "lang": "zh", "vip": 0},
    {"id": "436514312", "name": "成都", "artist": "赵雷", "dur": 328020, "pic": "https://p1.music.126.net/57o5J3oaf1srPog40IU1Aw==/109951174184968965.jpg", "lang": "zh", "vip": 0},
    {"id": "1293886117", "name": "年少有为", "artist": "李荣浩", "dur": 279196, "pic": "https://p2.music.126.net/tt8xwK-ASC2iqXNUXYKoDQ==/109951163606377163.jpg", "lang": "zh", "vip": 0},
    {"id": "2668397359", "name": "晴天", "artist": "RyaVocal", "dur": 270738, "pic": "https://p2.music.126.net/-NVLOT5vt9I91LRiZV1TCQ==/109951170413587092.jpg", "lang": "zh", "vip": 0},
    {"id": "2647102754", "name": "七里香", "artist": "吉拉朵", "dur": 261903, "pic": "https://p2.music.126.net/IrwKQCgK1Tov85bYDktxsg==/109951170157396676.jpg", "lang": "zh", "vip": 0},
    {"id": "3381542797", "name": "稻香", "artist": "周杰伦./街道办GDC/欧阳耀莹.", "dur": 120022, "pic": "https://p2.music.126.net/ZSzD7Y1Ox0EAc0Mi4f889g==/109951168734682555.jpg", "lang": "zh", "vip": 1},
    {"id": "3381543730", "name": "青花瓷", "artist": "周杰伦./街道办GDC/欧阳耀莹.", "dur": 95037, "pic": "https://p2.music.126.net/YmEhRPxVccR0ybs3CabMIA==/109951173214860541.jpg", "lang": "zh", "vip": 1},
    {"id": "3435952301", "name": "告白气球", "artist": "非常电台", "dur": 237374, "pic": "https://p2.music.126.net/wqj-JFJ1UCgMpQkUWtMwdA==/109951173936094984.jpg", "lang": "zh", "vip": 0},
    {"id": "569200213", "name": "消愁", "artist": "毛不易", "dur": 261346, "pic": "https://p2.music.126.net/vmCcDvD1H04e9gm97xsCqg==/109951163350929740.jpg", "lang": "zh", "vip": 0},
    {"id": "29715551", "name": "南山南", "artist": "马頔", "dur": 325079, "pic": "https://p2.music.126.net/CVJlM5yyYcdTFVn5gXtyOw==/109951172945818860.jpg", "lang": "zh", "vip": 0},
    {"id": "167870", "name": "如果当时", "artist": "许嵩", "dur": 316213, "pic": "https://p2.music.126.net/Zg4XDfsiRi5vawjSWPP8Ng==/109951172899966259.jpg", "lang": "zh", "vip": 0},
    {"id": "32507038", "name": "演员", "artist": "薛之谦", "dur": 261249, "pic": "https://p2.music.126.net/vu7SHbVlMuszmSuKR2SKAQ==/109951168707343730.jpg", "lang": "zh", "vip": 1},
    {"id": "1463165983", "name": "天外来物", "artist": "薛之谦", "dur": 257212, "pic": "https://p2.music.126.net/MgH6SepYHboKPr6FR8yg-w==/109951167040040692.jpg", "lang": "zh", "vip": 1},
    {"id": "516823132", "name": "大鱼", "artist": "周深", "dur": 317597, "pic": "https://p2.music.126.net/Ay5wDVF_0TXZmE2K_ljX4g==/109951171292487969.jpg", "lang": "zh", "vip": 1},
    {"id": "1901371647", "name": "孤勇者", "artist": "陈奕迅", "dur": 256000, "pic": "https://p2.music.126.net/HXfXIIBCk5w96MiY1Wdsqw==/109951171836610847.jpg", "lang": "zh", "vip": 1},
    {"id": "66842", "name": "十年", "artist": "陈奕迅", "dur": 205423, "pic": "https://p2.music.126.net/wECqsELfPFdVNLpW0QWhmA==/109951171836564936.jpg", "lang": "zh", "vip": 1},
    {"id": "66282", "name": "浮夸", "artist": "陈奕迅", "dur": 283520, "pic": "https://p2.music.126.net/W9imJx0w_JeCGGs43dfjFg==/109951171529987110.jpg", "lang": "zh", "vip": 1},
    {"id": "297839", "name": "爱你", "artist": "王心凌", "dur": 219626, "pic": "https://p2.music.126.net/8P1W00PwAVwLD_d-7vvxZw==/109951173007905115.jpg", "lang": "zh", "vip": 1},
    {"id": "108914", "name": "江南", "artist": "林俊杰", "dur": 267946, "pic": "https://p2.music.126.net/Gk4t93WwafRZtt9nTS77Iw==/109951171891430447.jpg", "lang": "zh", "vip": 1},
    {"id": "2714278532", "name": "泡沫", "artist": "G.E.M.邓紫棋", "dur": 258320, "pic": "https://p2.music.126.net/Dmg-cQJctLB_4ID4WRytIw==/109951171291365368.jpg", "lang": "zh", "vip": 1},
    {"id": "1405283464", "name": "句号", "artist": "G.E.M.邓紫棋", "dur": 235632, "pic": "https://p2.music.126.net/KTo5oSxH3CPA5PBTeFKDyA==/109951164581432409.jpg", "lang": "zh", "vip": 1},
    {"id": "449818741", "name": "光年之外", "artist": "G.E.M.邓紫棋", "dur": 235505, "pic": "https://p2.music.126.net/fkqFqMaEt0CzxYS-0NpCog==/18587244069235039.jpg", "lang": "zh", "vip": 1}
  ];

  function embedURL(kind, key) {
    if (kind === '163') return 'https://music.163.com/outchain/player?type=2&id=' + key + '&auto=1&height=66';
    if (kind === '163pl') return 'https://music.163.com/outchain/player?type=0&id=' + key + '&auto=0&height=430';
    if (kind === 'sc' || kind === 'scpl') {
      return 'https://w.soundcloud.com/player/?url=' + encodeURIComponent(key) +
        '&color=%237C6BF5&auto_play=true&hide_related=false&show_comments=false&show_user=true';
    }
    return String(key);
  }
  function findCh(id) { for (var i = 0; i < CHANNELS.length; i++) if (CHANNELS[i].id === id) return CHANNELS[i]; return CHANNELS[0]; }
  function byId(id) { for (var i = 0; i < TRACKS.length; i++) if (TRACKS[i].id === id) return TRACKS[i]; return null; }
  function isVipArtist(t) {
    if (!t) return false;
    if (t.vip) return true;
    for (var i = 0; i < VIP_ARTISTS.length; i++) if (t.artist && t.artist.indexOf(VIP_ARTISTS[i]) > -1) return true;
    return false;
  }
  /* 官方曲目页：完整收听 / 下载只走官方 */
  function officialURL(t) { return t ? 'https://music.163.com/#/song?id=' + t.id : 'https://music.163.com/'; }

  /* 把粘贴内容规整成可嵌入的 key */
  function parseKey(kind, raw) {
    raw = String(raw || '').trim();
    if (!raw) return '';
    if (kind === '163pl') {
      var m = raw.match(/playlist\?id=([0-9]+)/) || raw.match(/^([0-9]+)$/);
      return m ? m[1] : '';
    }
    if (kind === 'sc' || kind === 'scpl') {
      var m2 = raw.match(/soundcloud\.com\/(.+)$/);
      return 'https://soundcloud.com/' + (m2 ? m2[1].replace(/^\/+/, '') : raw);
    }
    return raw;
  }
  function hintOf(kind) {
    if (kind === '163pl') return '歌单 ID（music.163.com/playlist?id=数字）';
    if (kind === 'sc') return 'SoundCloud 曲目链接（soundcloud.com/作者/曲目）';
    if (kind === 'scpl') return 'SoundCloud 歌单链接';
    return '任意官方嵌入地址（https）';
  }

  Z.api = {
    CHANNELS: CHANNELS, TRACKS: TRACKS, VIP_ARTISTS: VIP_ARTISTS,
    embedURL: embedURL, findCh: findCh, byId: byId,
    isVipArtist: isVipArtist, officialURL: officialURL,
    parseKey: parseKey, hintOf: hintOf
  };
})(window);
