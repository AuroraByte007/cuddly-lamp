/* app.js —— 入口：装配各模块、绑定事件、启动
 * 顺序依赖：cipher → vault → cache → api → recommend → player → auth → shortcuts → ui → update → cloud-sync → app
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};
  var D = document;
  function el(id) { return D.getElementById(id); }

  Z.VERSION = '1.0.0';

  function bindCards() {
    D.addEventListener('click', function (e) {
      var act = e.target.closest && e.target.closest('[data-act]');
      if (act) {
        var c0 = act.closest('.card');
        if (c0) w.open(Z.api.officialURL(Z.api.byId(c0.getAttribute('data-id'))), '_blank');
        e.stopPropagation();
        return;
      }
      var chip = e.target.closest && e.target.closest('.chip[data-ch]');
      if (chip) {
        var id = chip.getAttribute('data-ch'), ch = Z.api.findCh(id);
        if (Z.vault.getSetting('on', {})[id] === 0) { Z.ui.toast('该通道已关闭'); return; }
        Z.player.setChannel(id);
        if (ch.kind === '163') {
          el('pasteBox').style.display = 'none';
          var t = Z.player.cur();
          if (t) Z.player.load(t, Z.player.state().queue, Z.player.state().i);
          else Z.ui.toast('先选择一首歌');
        } else {
          el('pasteBox').style.display = 'flex';
          el('stageTitle').textContent = '听歌台 · ' + ch.name;
          el('embedTip').classList.remove('hide');
          el('embedTip').textContent = '该通道需要粘贴 ' + ch.need;
          el('pasteBox').setAttribute('data-kind', ch.kind);
          el('pasteBox').setAttribute('data-ch', id);
          el('pasteInput').value = Z.vault.getSetting('paste_' + id, '');
        }
        return;
      }
      var card = e.target.closest && e.target.closest('.card');
      if (card) {
        var tid = card.getAttribute('data-id'), t = Z.api.byId(tid);
        if (!t) return;
        /* 归属哪一组：搜索结果用当前结果集，其它用今日推荐 */
        var q = Z.api.TRACKS, idx = 0;
        var grid = card.parentNode;
        if (grid && (grid.id === 'dailyGrid' || grid.id === 'likeGrid' || grid.id === 'searchGrid')) {
          q = [].map.call(grid.querySelectorAll('.card'), function (x) { return Z.api.byId(x.getAttribute('data-id')); })
            .filter(Boolean);
          idx = q.findIndex ? q.findIndex(function (x) { return x.id === t.id; }) : 0;
          if (idx < 0) idx = 0;
        } else {
          for (var i = 0; i < Z.api.TRACKS.length; i++) if (Z.api.TRACKS[i].id === t.id) idx = i;
          q = Z.api.TRACKS;
        }
        Z.player.setQueue(q, idx);
        Z.player.load(t, q, idx);
        el('btnFav').textContent = Z.recommend.isFav(t.id) ? '♥' : '♡';
      }
    });
  }

  function bindPlayer() {
    el('btnPlay').onclick = function () { Z.player.toggle(); };
    el('btnNext').onclick = function () { Z.player.next(); };
    el('btnPrev').onclick = function () { Z.player.prev(); };
    el('btnMode').onclick = function () { Z.player.cycleMode(); };
    el('btnFav').onclick = function () {
      var t = Z.player.cur();
      if (!t) { Z.ui.toast('先听一首歌'); return; }
      var on = Z.recommend.toggleFav(t);
      el('btnFav').textContent = on ? '♥' : '♡';
      Z.ui.toast(on ? '已收藏《' + t.name + '》' : '已取消收藏');
      Z.ui.paint();
    };
    el('btnDl').onclick = function () {
      var t = Z.player.cur();
      w.open(Z.api.officialURL(t), '_blank');
      Z.ui.toast('下载请走官方页面 / 客户端');
    };
    el('btnOfficial').onclick = function () { w.open(Z.api.officialURL(Z.player.cur()), '_blank'); };
    el('btnFull').onclick = function () { el('imm').classList.add('show'); Z.ui.immersion(Z.player.cur()); };
    el('immClose').onclick = function () { el('imm').classList.remove('show'); };
    el('pcv').onclick = function () { el('imm').classList.add('show'); Z.ui.immersion(Z.player.cur()); };
    el('btnAll').onclick = function () {
      var d = Z.recommend.daily();
      Z.player.setQueue(d, 0);
      Z.player.load(d[0], d, 0);
      Z.ui.toast('已将 ' + d.length + ' 首加入播放列表');
    };
    el('pasteGo').onclick = function () {
      var box = el('pasteBox'), kind = box.getAttribute('data-kind'), chId = box.getAttribute('data-ch');
      var key = Z.api.parseKey(kind, el('pasteInput').value);
      if (!key) { Z.ui.toast('地址或 ID 不完整'); return; }
      Z.vault.setSetting('paste_' + chId, el('pasteInput').value);
      var h = (kind === '163pl' || kind === 'custom') ? 430 : 166;
      var box2 = el('embed');
      [].forEach.call(box2.querySelectorAll('iframe'), function (f) { f.remove(); });
      var tip = el('embedTip');
      tip.classList.remove('hide');
      tip.textContent = '正在载入…';
      var f = D.createElement('iframe');
      f.src = Z.api.embedURL(kind, key);
      f.allow = 'autoplay; encrypted-media';
      f.setAttribute('frameborder', '0');
      f.style.height = h + 'px';
      f.onload = function () { tip.classList.add('hide'); };
      box2.appendChild(f);
      Z.player.state().mounted = true;
      el('btnPlay').textContent = '⏸';
      Z.ui.toast('已载入 ' + Z.api.findCh(chId).name);
    };
    el('pasteInput').onkeydown = function (e) { if (e.key === 'Enter') el('pasteGo').click(); };
  }

  function bindSearch() {
    var tm;
    el('q').oninput = function () {
      var v = this.value.trim();
      clearTimeout(tm);
      tm = setTimeout(function () {
        if (!v) {
          el('secSearch').style.display = 'none';
          el('secDaily').style.display = '';
          el('secLike').style.display = '';
          return;
        }
        var res = Z.api.TRACKS.filter(function (t) {
          return (t.name + t.artist).toLowerCase().indexOf(v.toLowerCase()) > -1;
        });
        el('secSearch').style.display = '';
        el('secDaily').style.display = 'none';
        el('secLike').style.display = 'none';
        el('sCount').textContent = '共 ' + res.length + ' 首';
        el('searchGrid').innerHTML = res.map(function (t) { return Z.ui.card(t); }).join('');
        Z.ui.hydrateCovers();
      }, 280);
    };
  }

  function bindDrawer() {
    el('btnSet').onclick = function () {
      el('drawer').classList.add('open');
      Z.shortcuts.render();
      renderChannels();
      Z.ui.cacheInfo();
      Z.auth.refreshVipRow();
    };
    el('drawerClose').onclick = function () { el('drawer').classList.remove('open'); };

    el('btnTheme').onclick = function () {
      var cur = Z.vault.getSetting('theme', 'dark');
      var nx = Z.ui.nextTheme(cur);
      Z.vault.setSetting('theme', nx);
      Z.ui.theme(nx);
      Z.ui.toast('主题：' + (nx === 'dark' ? '深夜' : nx === 'purple' ? '暮紫' : '浅色'));
    };

    D.addEventListener('click', function (e) {
      var tg = e.target.closest && e.target.closest('.toggle[data-k]');
      if (tg) {
        var k = tg.getAttribute('data-k');
        var v = Z.vault.getSetting(k, 0) ? 0 : 1;
        Z.vault.setSetting(k, v);
        tg.setAttribute('data-on', v);
        Z.ui.paint();
        Z.ui.toast((k === 'exYue' ? '排除粤语' : '排除英文') + (v ? ' 已开启' : ' 已关闭'));
        return;
      }
      var src = e.target.closest && e.target.closest('.toggle[data-src]');
      if (src) {
        var id = src.getAttribute('data-src');
        var on = Z.vault.getSetting('on', { A: 1, B: 1, C: 1, D: 1, E: 1 });
        on[id] = on[id] === 0 ? 1 : 0;
        Z.vault.setSetting('on', on);
        src.setAttribute('data-on', on[id]);
        Z.ui.tabs();
        Z.ui.toast(Z.api.findCh(id).name + (on[id] ? ' 已启用' : ' 已关闭'));
      }
    });

    el('resetRec').onclick = function () {
      Z.recommend.reset();
      Z.ui.paint();
      Z.ui.toast('推荐记录已重置');
    };
    var cc = el('btnClearCache');
    if (cc) cc.onclick = function () {
      Z.cache.clear().then(function () { Z.ui.cacheInfo(); Z.ui.toast('本地缓存已清空'); });
    };
    /* 云同步按钮（有则绑定） */
    var cp = el('btnCloudPush'), cl = el('btnCloudPull');
    if (cp) cp.onclick = function () {
      Z.cloud.push().then(function (r) {
        Z.ui.toast(r.local ? '未配置云端，已导出本地加密包' : (r.ok ? '密文已上传云端' : '上传失败，检查地址与权限'));
      });
    };
    if (cl) cl.onclick = function () {
      Z.cloud.pull().then(function (r) {
        Z.ui.toast(r.ok ? '已拉取云端密文并导入' : (r.msg || '拉取失败'));
        if (r.ok) { Z.ui.paint(); Z.auth.refreshVipRow(); }
      });
    };
  }

  function renderChannels() {
    var box = el('srcList');
    if (!box) return;
    var on = Z.vault.getSetting('on', { A: 1, B: 1, C: 1, D: 1, E: 1 });
    box.innerHTML = Z.api.CHANNELS.map(function (c) {
      return '<div class="row"><span>' + c.name + '</span>' +
        '<button class="toggle" data-src="' + c.id + '" data-on="' + (on[c.id] === 0 ? 0 : 1) + '"></button></div>';
    }).join('');
  }

  function bindShortcuts() {
    Z.shortcuts.bindRecorder();
    Z.shortcuts.bind({
      play: function () { Z.player.toggle(); },
      prev: function () { Z.player.prev(); },
      next: function () { Z.player.next(); },
      search: function () { el('q').focus(); },
      fav: function () { el('btnFav').click(); },
      official: function () { w.open(Z.api.officialURL(Z.player.cur()), '_blank'); },
      full: function () { el('imm').classList.add('show'); },
      mode: function () { Z.player.cycleMode(); },
      mini: function () {
        var b = el('bar');
        b.style.display = b.style.display === 'none' ? 'flex' : 'none';
      }
    });
  }

  function bindNet() {
    function paint() { Z.ui.offline(navigator.onLine); }
    w.addEventListener('online', function () { paint(); Z.ui.toast('已恢复联网'); });
    w.addEventListener('offline', function () { paint(); Z.ui.toast('已进入离线模式'); });
    paint();
  }

  function spark() {
    var sp = el('sp');
    if (!sp || sp.childNodes.length) return;
    for (var i = 0; i < 12; i++) {
      var b = D.createElement('i');
      b.style.animationDelay = (i * 0.08) + 's';
      sp.appendChild(b);
    }
  }

  function boot() {
    /* 先渲染再读盘：即使 IndexedDB 被受限，首屏也必须出来 */
    Z.ui.theme(Z.vault.getSetting('theme', 'dark'));
    Z.ui.paint();
    bindCards(); bindPlayer(); bindSearch(); bindDrawer(); bindShortcuts(); bindNet();
    Z.auth.bindLogin();
    Z.auth.bindRedeem();
    spark();
    Z.cache.init();
    Z.vault.init().then(function () {
      Z.ui.theme(Z.vault.getSetting('theme', 'dark'));
      Z.ui.paint();
      Z.shortcuts.render();
      renderChannels();
      Z.auth.refreshVipRow();
      if (Z.vault.get('profile', {}).phone) el('btnLogin').textContent = '已登录';
      var t = Z.player.cur();
      if (t) el('btnFav').textContent = Z.recommend.isFav(t.id) ? '♥' : '♡';
      /* 缓存自检 + 版本检查（后台静默） */
      setTimeout(function () { Z.cache.stats().then(Z.ui.cacheInfo); }, 800);
      setTimeout(function () { Z.update.check(true); }, 1500);
      if (Z.vault.get('profile', {}).phone) el('btnLogin').textContent = '已登录';
    }).catch(function (e) {
      Z.ui.toast('本地存储初始化失败：' + e.message);
      Z.ui.paint();
      bindCards(); bindPlayer();
    });
  }

  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', boot); else boot();
})(window);
