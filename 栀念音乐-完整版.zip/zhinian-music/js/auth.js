/* auth.js —— 登录与 VIP
 * 登录：手机号 11 位 → 获取验证码(30s 括号冷却) → 3s 内自动复制 6 位码
 *       「无法获取兑换码」新开页给随机码 → 回填 → 滑块人机验证
 * VIP：兑换码有效期 72 小时，状态加密写入 profile.dat
 *      非 VIP 听 VIP 曲目最多 1/3（判定在 player.js）
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};
  var D = document;
  var CODES = ['1110999', 'vip111', 'ch666'];   /* 只在代码内部校验，界面永不展示 */
  var DECOY = '666666';
  var HIDDEN = '2331122';
  var TTL = 72 * 60 * 60 * 1000;                /* 三天 */

  function el(id) { return D.getElementById(id); }
  function prof() { return Z.vault.get('profile', {}); }
  function isVip() {
    var p = prof();
    return !!(p.vipExpire && p.vipExpire > Date.now());
  }
  function leftText() {
    var p = prof();
    if (!p.vipExpire || p.vipExpire <= Date.now()) return '未激活';
    var ms = p.vipExpire - Date.now();
    var h = Math.floor(ms / 3600000), m = Math.floor(ms % 3600000 / 60000);
    return '剩 ' + h + ' 小时 ' + m + ' 分';
  }

  /* 激活 / 续期：相同的码重复输入按续期计算，从当前到期时间往后加 */
  function redeem(code) {
    code = String(code || '').trim();
    if (CODES.indexOf(code) < 0) return { ok: false, msg: '兑换码无效' };
    var p = prof();
    var base = (p.vipExpire && p.vipExpire > Date.now()) ? p.vipExpire : Date.now();
    p.vipExpire = base + TTL;
    Z.vault.set('profile', p);
    Z.ui.paint();
    refreshVipRow();
    return { ok: true, msg: 'VIP 已激活，有效期至 ' + new Date(p.vipExpire).toLocaleString() };
  }

  function refreshVipRow() {
    var n = el('vipState');
    if (n) n.textContent = isVip() ? leftText() : '未激活（VIP 曲目可试听 1/3）';
    var b = el('btnLogin');
    if (b && prof().phone) b.textContent = '已登录';
  }

  /* ---------- 登录弹层 ---------- */
  function bindLogin() {
    var A = { left: 0, used: false, timer: null, code: '' };
    var phone = el('phone');
    function state() {
      var b = el('btnCode'), ok = /^1[3-9]\d{9}$/.test(phone.value);
      if (A.left > 0) {
        b.className = 'btn-code counting';
        b.disabled = true;
        b.textContent = (A.used ? '重新获取验证码' : '获取验证码') + '(' + A.left + 's)';
        return;
      }
      b.disabled = !ok;
      b.className = 'btn-code' + (ok ? ' active' : '');
      b.textContent = A.used ? '重新获取验证码' : '获取验证码';
    }
    el('btnLogin').onclick = function () {
      el('loginMask').classList.add('show');
      if (prof().phone) { phone.value = prof().phone; state(); }
    };
    el('loginClose').onclick = function () { el('loginMask').classList.remove('show'); };
    phone.oninput = function () {
      this.value = this.value.replace(/\D/g, '').slice(0, 11);
      var bad = this.value.length === 11 && !/^1[3-9]\d{9}$/.test(this.value);
      this.classList.toggle('bad', bad);
      el('phoneErr').textContent = bad ? '请输入正确的手机号' : '';
      state();
    };
    el('btnCode').onclick = function () {
      if (this.disabled) return;
      A.code = String(Math.floor(100000 + Math.random() * 900000));
      A.used = true; A.left = 30; state();
      Z.ui.toast('兑换码已发送（本地演示）');
      clearInterval(A.timer);
      A.timer = setInterval(function () {
        A.left--;
        if (A.left <= 0) { clearInterval(A.timer); A.left = 0; }
        state();
      }, 1000);
      setTimeout(function () {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(A.code)
            .then(function () { Z.ui.toast('兑换码已自动复制：' + A.code); })
            .catch(function () { Z.ui.toast('请手动复制：' + A.code); });
        } else Z.ui.toast('请手动复制：' + A.code);
      }, 900);
    };
    el('noCode').onclick = function () {
      var code = String(Math.floor(100000 + Math.random() * 900000));
      var win = w.open('', '_blank', 'width=420,height=430');
      if (!win) { Z.ui.toast('弹窗被拦截'); return; }
      win.document.write('<!DOCTYPE html><title>栀念 · 兑换码</title>' +
        '<body style="margin:0;display:grid;place-items:center;height:100vh;background:#0E0F13;' +
        'color:#E7E9EF;font-family:system-ui;text-align:center">' +
        '<div><p style="color:#9AA0AE;font-size:13px">你的兑换码（可复制后粘贴）</p>' +
        '<div id="c" style="font:700 40px/1.2 ui-monospace,Consolas,monospace;letter-spacing:6px;color:#7C6BF5">' + code + '</div>' +
        '<button id="b" style="margin-top:14px;height:38px;padding:0 18px;border:0;border-radius:10px;cursor:pointer;' +
        'background:linear-gradient(135deg,#7C6BF5,#5FD3C4);color:#fff">复制</button></div>' +
        '<script>document.getElementById("b").onclick=function(){var t=document.getElementById("c").textContent;' +
        'if(navigator.clipboard){navigator.clipboard.writeText(t).then(function(){document.getElementById("b").textContent="已复制"})}' +
        'else{var s=window.getSelection(),r=document.createRange();r.selectNodeContents(document.getElementById("c"));' +
        's.removeAllRanges();s.addRange(r);document.execCommand("copy");document.getElementById("b").textContent="已复制"}}<\/script></body>');
      win.document.close();
    };

    /* 滑块人机验证 */
    var piece = el('piece'), track = el('track'), drag = false, start = 0, gap = 0;
    function reset() { gap = Math.round((track.clientWidth - 46) * (0.55 + Math.random() * 0.3)); }
    setTimeout(reset, 150);
    w.addEventListener('resize', reset);
    function down(x) { drag = true; start = x - piece.offsetLeft; }
    function move(x) {
      if (!drag) return;
      var max = track.clientWidth - 46;
      var pos = Math.max(0, Math.min(max, x - start));
      piece.style.left = pos + 'px';
      if (Math.abs(pos - gap) <= 6) {
        drag = false;
        piece.classList.add('done');
        piece.textContent = '✓';
        piece.style.left = gap + 'px';
        el('capTip').textContent = '验证通过';
      }
    }
    piece.addEventListener('mousedown', function (e) { down(e.clientX); });
    piece.addEventListener('touchstart', function (e) { down(e.touches[0].clientX); }, { passive: true });
    D.addEventListener('mousemove', function (e) { move(e.clientX); });
    D.addEventListener('touchmove', function (e) { move(e.touches[0].clientX); }, { passive: true });
    D.addEventListener('mouseup', function () {
      if (!drag) return;
      drag = false;
      if (!piece.classList.contains('done')) piece.style.left = '0px';
    });

    el('btnSubmit').onclick = function () {
      if (!/^\d{6}$/.test(el('pcode').value)) { Z.ui.toast('请输入 6 位兑换码'); return; }
      if (!piece.classList.contains('done')) { Z.ui.toast('请先完成人机验证'); return; }
      var p = prof();
      p.phone = phone.value;
      p.loginAt = Date.now();
      Z.vault.set('profile', p);
      el('loginMask').classList.remove('show');
      el('btnLogin').textContent = '已登录';
      Z.ui.toast('登录成功，欢迎回来');
      refreshVipRow();
    };
    state();
  }

  /* ---------- VIP 兑换（输入全程 * ） ---------- */
  function bindRedeem() {
    var raw = '';
    var input = el('rcode');
    if (!input) return;
    el('btnRedeem').onclick = function () { el('redeemMask').classList.add('show'); input.focus(); };
    el('redeemClose').onclick = function () { el('redeemMask').classList.remove('show'); };
    input.onkeydown = function (e) {
      if (e.key === 'Backspace') {
        raw = raw.slice(0, -1);
        input.value = '*'.repeat(raw.length);
        e.preventDefault(); return;
      }
      if (e.key === 'Enter') { el('btnRedeemGo').click(); return; }
      if (e.key.length === 1 && /[a-zA-Z0-9]/.test(e.key)) {
        if (raw.length < 16) raw += e.key;
        input.value = '*'.repeat(raw.length);
        e.preventDefault();
      }
    };
    input.onpaste = function (e) {
      e.preventDefault();
      var t = (e.clipboardData || w.clipboardData).getData('text') || '';
      raw = (raw + t.replace(/[^a-zA-Z0-9]/g, '')).slice(0, 16);
      input.value = '*'.repeat(raw.length);
    };
    el('btnRedeemGo').onclick = function () {
      var v = raw;
      raw = '';
      input.value = '';
      if (v === DECOY) { el('redeemMask').classList.remove('show'); egg(); return; }
      var r = redeem(v);
      el('redeemTip').textContent = r.msg;
      Z.ui.toast(r.msg);
      if (r.ok) setTimeout(function () { el('redeemMask').classList.remove('show'); el('redeemTip').textContent = ''; }, 1400);
    };
    refreshVipRow();
  }

  /* 温和彩蛋：黑 → 紫，随时可关，不锁页面 */
  function egg() {
    var box = D.createElement('div');
    box.id = 'eggBox';
    box.style.cssText = 'position:fixed;inset:0;z-index:9999;display:grid;place-items:center;' +
      'background:#050508;transition:background 1.2s ease,opacity .4s ease;font-family:system-ui;color:#E7E9EF';
    box.innerHTML = '<div style="text-align:center;max-width:420px;padding:24px">' +
      '<p style="font-size:13px;color:#8A8F9E;margin:0 0 14px">这里好像有点不对劲</p>' +
      '<div style="font:700 26px/1.4 system-ui;margin-bottom:18px">栀念音乐</div>' +
      '<input id="eggIn" maxlength="7" placeholder="输入点什么" style="height:38px;padding:0 12px;border-radius:10px;' +
      'border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:#fff;text-align:center;' +
      'letter-spacing:4px;outline:none">' +
      '<div id="eggMsg" style="min-height:22px;margin-top:12px;font-size:14px;color:#C9B8FF"></div>' +
      '<button id="eggOut" style="margin-top:16px;height:34px;padding:0 16px;border:0;border-radius:9px;cursor:pointer;' +
      'background:rgba(255,255,255,.1);color:#C9C9D2;font-size:12px">先不玩</button></div>';
    D.body.appendChild(box);
    setTimeout(function () { box.style.background = 'linear-gradient(160deg,#2A1750,#5B2E9C 55%,#120A1F)'; }, 60);
    box.querySelector('#eggIn').onkeydown = function (e) {
      if (e.key !== 'Enter') return;
      if (this.value.trim() === HIDDEN) box.querySelector('#eggMsg').textContent = '劳幕私😂';
      else box.querySelector('#eggMsg').textContent = '不对哦';
    };
    box.querySelector('#eggOut').onclick = function () {
      box.style.opacity = '0';
      setTimeout(function () { box.remove(); }, 380);
    };
  }

  Z.auth = {
    isVip: isVip, leftText: leftText, redeem: redeem,
    refreshVipRow: refreshVipRow,
    bindLogin: bindLogin, bindRedeem: bindRedeem, egg: egg,
    TTL: TTL
  };
})(window);
