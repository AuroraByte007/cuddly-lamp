/* cache.js —— 本地缓存（上限 500MB，LRU 淘汰）
 * 能缓存什么，取决于资源服务器是否允许跨域读取：
 *   - 允许 CORS 的封面图 / 音频：抓到 Blob 存 IndexedDB，离线可复用
 *   - 不允许 CORS（多数音乐平台）：抓取失败即跳过，不占空间
 * 对外：ZN.cache.put(url) / getURL(url) / stats() / clear() / prune()
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};
  var MAX = 500 * 1024 * 1024;       /* 500MB 上限 */
  var DB = 'zn_cache', STORE = 'items';
  var dbp = null, objUrls = {};

  function open() {
    if (dbp) return dbp;
    dbp = new Promise(function (res, rej) {
      var r = w.indexedDB && w.indexedDB.open(DB, 1);
      if (!r) { rej(new Error('no indexedDB')); return; }
      r.onupgradeneeded = function () { r.result.createObjectStore(STORE); };
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
    });
    return dbp;
  }
  function tx(mode, fn) {
    return open().then(function (db) {
      return new Promise(function (res, rej) {
        var t = db.transaction(STORE, mode), st = t.objectStore(STORE), req = fn(st), out;
        if (req) { req.onsuccess = function () { out = req.result; }; }
        t.oncomplete = function () { res(out); };
        t.onerror = function () { rej(t.error); };
      });
    });
  }

  var C = {
    MAX: MAX,
    init: function () { return tx('readonly', function (st) { st.count(); }).catch(function () { return 0; }); },

    /* 抓资源入缓存；返回 true/false（失败不抛错，避免打断播放） */
    put: function (url, kind) {
      if (!url || /^data:/.test(url)) return Promise.resolve(false);
      if (objUrls[url]) return Promise.resolve(true);
      return fetch(url, { mode: 'cors', credentials: 'omit' }).then(function (r) {
        if (!r.ok) return false;
        return r.blob().then(function (b) {
          if (!b || b.size < 64 || b.type.indexOf('opaque') > -1) return false;
          return C.prune(b.size).then(function () {
            return tx('readwrite', function (st) {
              st.put({ url: url, kind: kind || 'file', blob: b, size: b.size, used: Date.now() }, url);
            }).then(function () { return true; }).catch(function () { return false; });
          });
        });
      }).catch(function () { return false; });
    },

    /* 取缓存的可视地址（ObjectURL），未命中返回 null */
    getURL: function (url) {
      if (objUrls[url]) return Promise.resolve(objUrls[url]);
      return tx('readonly', function (st) { st.get(url); }).then(function (rec) {
        if (!rec || !rec.blob) return null;
        var u = URL.createObjectURL(rec.blob);
        objUrls[url] = u;
        tx('readwrite', function (st) { rec.used = Date.now(); st.put(rec, url); }).catch(function () {});
        return u;
      }).catch(function () { return null; });
    },

    all: function () { return tx('readonly', function (st) { st.getAll(); }).then(function (a) { return a || []; }).catch(function () { return []; }); },

    stats: function () {
      return C.all().then(function (list) {
        var used = 0;
        for (var i = 0; i < list.length; i++) used += list[i].size || 0;
        return { used: used, max: MAX, count: list.length, percent: Math.min(100, used / MAX * 100) };
      });
    },

    /* 超限时按最久未用淘汰，直到能容纳 incoming */
    prune: function (incoming) {
      incoming = incoming || 0;
      return C.all().then(function (list) {
        var used = 0, i;
        for (i = 0; i < list.length; i++) used += list[i].size || 0;
        if (used + incoming <= MAX) return 0;
        list.sort(function (a, b) { return (a.used || 0) - (b.used || 0); });
        var freed = 0, drop = [];
        for (i = 0; i < list.length && used + incoming - freed > MAX; i++) {
          drop.push(list[i].url); freed += list[i].size || 0;
        }
        return tx('readwrite', function (st) {
          drop.forEach(function (u) { st.delete(u); if (objUrls[u]) { URL.revokeObjectURL(objUrls[u]); delete objUrls[u]; } });
        }).then(function () { return freed; });
      });
    },

    clear: function () {
      Object.keys(objUrls).forEach(function (u) { URL.revokeObjectURL(objUrls[u]); });
      objUrls = {};
      return tx('readwrite', function (st) { st.clear(); }).then(function () { return true; }).catch(function () { return false; });
    },

    human: function (n) {
      if (n >= 1024 * 1024 * 1024) return (n / 1073741824).toFixed(2) + ' GB';
      if (n >= 1024 * 1024) return (n / 1048576).toFixed(1) + ' MB';
      if (n >= 1024) return (n / 1024).toFixed(0) + ' KB';
      return n + ' B';
    }
  };
  Z.cache = C;
})(window);
