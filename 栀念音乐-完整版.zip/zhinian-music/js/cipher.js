/* cipher.js —— 自研 64bit 分组加密（严格复刻给定的 enc / dec）
 * 单块 8 字节：L 前 4 字节、R 后 4 字节，16 轮 Feistel 结构
 * 在其上加：PKCS7 填充 + CBC 链式 + Base64 打包（iv | ct）
 * 对外：ZN.cipher.encrypt(text, key) / decrypt(pack, key) / encBlock / decBlock
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};
  var M = 0xFFFFFFFF, BLK = 8;

  function mul(x, y) { return (Math.imul(x, y) >>> 0); }
  function add() {
    var s = 0;
    for (var i = 0; i < arguments.length; i++) { s += arguments[i]; if (s > 9007199254740991) s = s % 4294967296; }
    return s % 4294967296 >>> 0;
  }
  function rotl(x, n) { return (((x << n) | (x >>> (32 - n))) >>> 0); }

  /* 轮密钥表：16 个 32 位数 */
  function table(k) {
    var a = 0x9e3779b9, r = [], i;
    for (i = 0; i < 16; i++) {
      a = add(mul(a, 1103515245), k[i % k.length], mul(i, 0x85ebca6b));
      r.push(a);
    }
    return r;
  }
  function F(R, r) {
    var t = add(R, r);
    t = rotl(t, 7);
    t = mul(t, 0x85ebca6b);
    t = (t ^ (t >>> 15)) >>> 0;
    t = rotl(t, 11);
    return t;
  }

  /* 单块加密：入 8 字节 -> 出 8 字节（R16 | L16） */
  function encBlock(m, k) {
    var r = table(k);
    var L = ((m[0] << 24) | (m[1] << 16) | (m[2] << 8) | m[3]) >>> 0;
    var R = ((m[4] << 24) | (m[5] << 16) | (m[6] << 8) | m[7]) >>> 0;
    for (var i = 0; i < 16; i++) {
      var t = F(R, r[i]);
      var nL = R, nR = (L ^ t) >>> 0;
      L = nL; R = nR;
    }
    return [R >>> 24 & 255, R >>> 16 & 255, R >>> 8 & 255, R & 255,
      L >>> 24 & 255, L >>> 16 & 255, L >>> 8 & 255, L & 255];
  }

  /* 单块解密：入 8 字节 -> 出 8 字节（L0 | R0） */
  function decBlock(c, k) {
    var r = table(k);
    var L = ((c[4] << 24) | (c[5] << 16) | (c[6] << 8) | c[7]) >>> 0;
    var R = ((c[0] << 24) | (c[1] << 16) | (c[2] << 8) | c[3]) >>> 0;
    for (var i = 15; i >= 0; i--) {
      var t = F(L, r[i]);
      var nL = (R ^ t) >>> 0, nR = L;
      L = nL; R = nR;
    }
    return [L >>> 24 & 255, L >>> 16 & 255, L >>> 8 & 255, L & 255,
      R >>> 24 & 255, R >>> 16 & 255, R >>> 8 & 255, R & 255];
  }

  /* ---------- 密钥 ---------- */
  function keyBytes(key) {
    if (Array.isArray(key)) return key.slice();
    if (key instanceof Uint8Array) return Array.prototype.slice.call(key);
    var s = String(key == null ? 'zhinian-music' : key), out = [];
    for (var i = 0; i < s.length; i++) out.push(s.charCodeAt(i) & 255);
    return out.length ? out : [1, 2, 3, 4];
  }

  /* ---------- UTF-8 ---------- */
  function utf8(s) {
    var out = [], i, c;
    for (i = 0; i < s.length; i++) {
      c = s.charCodeAt(i);
      if (c < 0x80) out.push(c);
      else if (c < 0x800) out.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f));
      else if (c < 0xd800 || c >= 0xe000) out.push(0xe0 | (c >> 12), 0x80 | (c >> 6 & 0x3f), 0x80 | (c & 0x3f));
      else { var d = s.charCodeAt(++i); var cp = 0x10000 + (((c - 0xd800) << 10) | (d - 0xdc00));
        out.push(0xf0 | (cp >> 18), 0x80 | (cp >> 12 & 0x3f), 0x80 | (cp >> 6 & 0x3f), 0x80 | (cp & 0x3f)); }
    }
    return out;
  }
  function fromUtf8(b) {
    var s = '', i = 0, c;
    while (i < b.length) {
      c = b[i++];
      if (c < 0x80) s += String.fromCharCode(c);
      else if (c < 0xe0) s += String.fromCharCode((c & 0x1f) << 6 | b[i++] & 0x3f);
      else if (c < 0xf0) s += String.fromCharCode((c & 0x0f) << 12 | (b[i++] & 0x3f) << 6 | b[i++] & 0x3f);
      else { var cp = (c & 7) << 18 | (b[i++] & 0x3f) << 12 | (b[i++] & 0x3f) << 6 | (b[i++] & 0x3f);
        cp -= 0x10000; s += String.fromCharCode(0xd800 + (cp >> 10), 0xdc00 + (cp & 0x3ff)); }
    }
    return s;
  }

  /* ---------- PKCS7 ---------- */
  function pad(b) {
    var n = BLK - (b.length % BLK), out = b.slice();
    for (var i = 0; i < n; i++) out.push(n);
    return out;
  }
  function unpad(b) {
    var n = b[b.length - 1];
    if (!n || n > BLK || n > b.length) throw new Error('bad padding');
    for (var i = 0; i < n; i++) if (b[b.length - 1 - i] !== n) throw new Error('bad padding');
    return b.slice(0, b.length - n);
  }

  /* ---------- Base64 ---------- */
  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  function toB64(b) {
    var out = '', i;
    for (i = 0; i < b.length; i += 3) {
      var a1 = b[i], a2 = b[i + 1], a3 = b[i + 2];
      out += B64[a1 >> 2] + B64[(a1 & 3) << 4 | (a2 === undefined ? 0 : a2 >> 4)];
      out += a2 === undefined ? '=' : B64[(a2 & 15) << 2 | (a3 === undefined ? 0 : a3 >> 6)];
      out += a3 === undefined ? '=' : B64[a3 & 63];
    }
    return out;
  }
  function fromB64(s) {
    var out = [], i, n;
    s = String(s).replace(/[^A-Za-z0-9+/=]/g, '');
    for (i = 0; i < s.length; i += 4) {
      n = (B64.indexOf(s[i]) << 18) | (B64.indexOf(s[i + 1]) << 12) |
        ((s[i + 2] === '=' ? 0 : B64.indexOf(s[i + 2])) << 6) | (s[i + 3] === '=' ? 0 : B64.indexOf(s[i + 3]));
      out.push(n >> 16 & 255);
      if (s[i + 2] !== '=') out.push(n >> 8 & 255);
      if (s[i + 3] !== '=') out.push(n & 255);
    }
    return out;
  }

  /* ---------- CBC ---------- */
  function xorBlock(a, b) { for (var i = 0; i < BLK; i++) a[i] = (a[i] ^ b[i]) & 255; return a; }

  function encrypt(text, key) {
    var k = keyBytes(key), iv = [], i;
    for (i = 0; i < BLK; i++) iv.push(Math.floor(Math.random() * 256));
    var plain = pad(utf8(String(text))), prev = iv.slice(), out = [], p, c;
    for (i = 0; i < plain.length; i += BLK) {
      p = xorBlock(plain.slice(i, i + BLK), prev);
      c = encBlock(p, k);
      out.push.apply(out, c);
      prev = c;
    }
    return toB64(iv.concat(out));
  }

  function decrypt(pack, key) {
    var k = keyBytes(key), all = fromB64(pack);
    if (all.length < BLK * 2) throw new Error('cipher too short');
    var iv = all.slice(0, BLK), ct = all.slice(BLK), prev = iv.slice(), out = [], c, p;
    for (var i = 0; i < ct.length; i += BLK) {
      c = ct.slice(i, i + BLK);
      if (c.length < BLK) throw new Error('bad block');
      p = xorBlock(decBlock(c, k), prev);
      out.push.apply(out, p);
      prev = c;
    }
    return fromUtf8(unpad(out));
  }

  Z.cipher = {
    BLK: BLK,
    encBlock: encBlock, decBlock: decBlock,
    table: table, keyBytes: keyBytes,
    encrypt: encrypt, decrypt: decrypt,
    toB64: toB64, fromB64: fromB64
  };
})(window);
