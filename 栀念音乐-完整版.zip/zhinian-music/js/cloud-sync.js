/* cloud-sync.js —— 云端备份（只上传密文）
 * 支持 WebDAV：PUT / GET 到 {endpoint}/{uid}/xxx.dat
 * 未配置 endpoint 时，退化为本地导出（下载一个包含 5 个密文文件的包）
 * 密钥不上云，云端拿到的只是 cipher 加密后的乱码
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};
  var D = document;

  function endpoint() { return String(Z.vault.getSetting('cloudEndpoint', '') || '').replace(/\/+$/, ''); }
  function uid() {
    var p = Z.vault.get('profile', {});
    return (p.phone || 'local').replace(/\D/g, '') || 'local';
  }

  function push() {
    var ep = endpoint();
    var files = Z.vault.exportFiles();
    if (!ep) {
      downloadLocal(files);
      return Promise.resolve({ ok: true, count: 0, local: true });
    }
    var names = Object.keys(files);
    var base = ep + '/' + uid() + '/';
    return Promise.all(names.map(function (n) {
      return fetch(base + n, { method: 'PUT', body: files[n], headers: { 'Content-Type': 'text/plain' } })
        .then(function (r) { return r.ok ? 1 : 0; }).catch(function () { return 0; });
    })).then(function (arr) {
      var ok = arr.reduce(function (a, b) { return a + b; }, 0);
      return { ok: ok > 0, count: ok };
    });
  }

  function pull() {
    var ep = endpoint();
    if (!ep) return Promise.resolve({ ok: false, msg: '未配置云端地址' });
    var names = ['profile.dat', 'favorite.dat', 'history.dat', 'settings.dat'];
    var base = ep + '/' + uid() + '/', obj = {};
    return Promise.all(names.map(function (n) {
      return fetch(base + n, { cache: 'no-store' }).then(function (r) { return r.ok ? r.text() : ''; })
        .then(function (t) { if (t) obj[n] = t; }).catch(function () {});
    })).then(function () {
      return Z.vault.importFiles(obj).then(function (n) { return { ok: n > 0, count: n }; });
    });
  }

  function downloadLocal(files) {
    var txt = JSON.stringify(files, null, 1);
    var a = D.createElement('a');
    a.href = 'data:application/json;charset=utf-8,' + encodeURIComponent(txt);
    a.download = 'znyy-user-data-' + new Date().toISOString().slice(0, 10) + '.json';
    D.body.appendChild(a); a.click(); a.remove();
    Z.ui.toast('已导出加密数据包');
  }

  Z.cloud = { push: push, pull: pull, endpoint: endpoint, exportLocal: function () { downloadLocal(Z.vault.exportFiles()); } };
})(window);
