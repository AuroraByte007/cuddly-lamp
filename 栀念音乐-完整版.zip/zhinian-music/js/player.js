/* player.js —— 播放编排：官方嵌入 iframe + 进度计时 + 四种循环模式
 * 说明：iframe 内部进度脚本读不到，这里是「估算进度」；
 *      VIP 曲目的 1/3 限制靠上层计时到点卸载实现。
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};
  var D = document;

  var S = {
    queue: [], i: -1, mode: 'list', ch: 'A',
    mounted: false, elapsed: 0, dur: 0, limit: 0, tick: null
  };
  var MODES = [['list', '↻', '列表循环'], ['single', '①', '单曲循环'], ['sequence', '→', '顺序播放'], ['shuffle', '⇄', '随机播放']];

  function el(id) { return D.getElementById(id); }
  function chOn(id) {
    var o = Z.vault.getSetting('on', { A: 1, B: 1, C: 1, D: 1, E: 1 });
    return o[id] !== 0;
  }
  function cur() { return S.queue[S.i] || null; }

  function stopTick() { clearInterval(S.tick); S.tick = null; }

  function startTick() {
    stopTick();
    if (!S.dur) { Z.ui.progress(0, 0, 0); return; }
    S.tick = setInterval(function () {
      S.elapsed += 1000;
      Z.ui.progress(S.elapsed, S.dur, S.elapsed / S.dur * 100);
      if (S.limit && S.elapsed >= S.limit) {
        unmount('VIP 曲目试听 1/3 已结束，输入兑换码可解锁');
        Z.ui.toast('仅可试听 1/3：输入兑换码解锁，或直接选下一首');
        Z.ui.bar(cur(), ' · 试听已结束');
        return;
      }
      if (S.elapsed >= S.dur) next(true);
    }, 1000);
  }

  function mount(src, h) {
    var box = el('embed'), tip = el('embedTip');
    [].forEach.call(box.querySelectorAll('iframe'), function (f) { f.remove(); });
    tip.classList.remove('hide');
    tip.textContent = '正在载入官方播放器…';
    var f = D.createElement('iframe');
    f.src = src;
    f.allow = 'autoplay; encrypted-media';
    f.setAttribute('frameborder', '0');
    f.style.height = (h || 66) + 'px';
    f.onload = function () { tip.classList.add('hide'); };
    box.appendChild(f);
    S.mounted = true;
    el('btnPlay').textContent = '⏸';
    /* 6 秒无 load 视为该通道不可达 */
    var loaded = false;
    f.addEventListener('load', function () { loaded = true; });
    setTimeout(function () {
      if (!loaded) tip.textContent = '该通道当前网络不可达，可切回网易云通道或粘贴自有地址';
    }, 6000);
  }

  function unmount(msg) {
    var box = el('embed'), tip = el('embedTip');
    [].forEach.call(box.querySelectorAll('iframe'), function (f) { f.remove(); });
    tip.classList.remove('hide');
    tip.textContent = msg || '已停止，选择一首歌重新载入';
    S.mounted = false;
    S.elapsed = 0;
    stopTick();
    el('btnPlay').textContent = '▶';
  }

  /* 载入一首歌 */
  function load(t, queue, idx) {
    if (!t) return;
    S.queue = queue || Z.api.TRACKS;
    S.i = (idx === undefined || idx < 0) ? 0 : idx;
    if (!S.queue.length) S.queue = [t];

    var vipLocked = Z.api.isVipArtist(t) && !Z.auth.isVip();
    S.dur = t.dur || 0;
    S.limit = vipLocked ? Math.floor(S.dur / 3) : 0;
    S.elapsed = 0;

    Z.ui.bar(t, vipLocked ? ' · VIP 试听 1/3' : '');
    Z.ui.immersion(t);
    Z.ui.progress(0, S.dur, 0);

    var ch = Z.api.findCh(S.ch);
    if (ch.kind !== '163') { Z.ui.toast('请在「' + ch.name + '」下粘贴链接后播放'); return; }

    el('stageTitle').textContent = '听歌台 · ' + ch.name + '官方播放器';
    el('pasteBox').style.display = 'none';
    mount(Z.api.embedURL('163', t.id), 66);

    if (vipLocked) Z.ui.toast('VIP 曲目：非会员可试听 1/3 时长');
    Z.recommend.addHistory(t);
    startTick();
    Z.ui.tabs();
  }

  function next(auto) {
    if (!S.queue.length) return;
    if (S.mode === 'single') { load(S.queue[S.i], S.queue, S.i); return; }
    var n;
    if (S.mode === 'shuffle') {
      if (S.queue.length === 1) n = 0;
      else do { n = Math.floor(Math.random() * S.queue.length); } while (n === S.i);
    } else n = S.i + 1;
    if (n >= S.queue.length) {
      if (S.mode === 'sequence') { unmount('播放列表已结束'); return; }
      n = 0;
    }
    load(S.queue[n], S.queue, n);
  }
  function prev() {
    if (!S.queue.length) return;
    var n = S.mode === 'shuffle' ? Math.floor(Math.random() * S.queue.length) : S.i - 1;
    if (n < 0) n = S.queue.length - 1;
    load(S.queue[n], S.queue, n);
  }
  function cycleMode() {
    var i = 0;
    for (var k = 0; k < MODES.length; k++) if (MODES[k][0] === S.mode) i = k;
    var m = MODES[(i + 1) % MODES.length];
    S.mode = m[0];
    el('btnMode').textContent = m[1];
    el('btnMode').setAttribute('data-mode', m[0]);
    el('modeLabel').textContent = m[2];
    Z.ui.toast(m[2]);
  }
  function toggle() {
    if (S.mounted) { unmount('已停止'); return; }
    var t = cur();
    if (!t) { var d = Z.recommend.daily(); load(d[0], d, 0); return; }
    load(t, S.queue, S.i);
  }
  function setChannel(id) {
    S.ch = id;
    Z.ui.tabs();
  }
  function setQueue(list, startIdx) {
    S.queue = list || Z.api.TRACKS;
    S.i = startIdx || 0;
  }

  Z.player = {
    load: load, next: function () { next(); }, prev: prev, cycleMode: cycleMode,
    toggle: toggle, setChannel: setChannel, setQueue: setQueue,
    unmount: unmount, cur: cur,
    state: function () { return S; },
    modes: MODES
  };
})(window);
