/* recommend.js —— 每日推荐（日期种子 24 首）与猜你喜欢（加权 + 语种排除）
 * 数据来自 vault：history（收听记录）、favorite（收藏）、settings（排除开关）
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};

  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function seedOf(str) {
    var h = 2166136261;
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function dayKey() {
    var d = new Date();
    return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  }

  function count() {
    var h = Z.vault.get('history', []), m = {};
    for (var i = 0; i < h.length; i++) m[h[i].id] = (m[h[i].id] || 0) + 1;
    return m;
  }

  function daily() {
    var r = rng(seedOf('zn-daily-' + dayKey()));
    var arr = Z.api.TRACKS.slice();
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(r() * (i + 1)), t = arr[i];
      arr[i] = arr[j]; arr[j] = t;
    }
    var out = [], seen = {};
    for (i = 0; i < arr.length && out.length < 24; i++) {
      if (!seen[arr[i].id]) { seen[arr[i].id] = 1; out.push(arr[i]); }
    }
    return out;
  }

  function filterLang(list) {
    var exYue = Z.vault.getSetting('exYue', 0), exEn = Z.vault.getSetting('exEn', 0);
    return list.filter(function (t) {
      if (exYue && t.lang === 'yue') return false;
      if (exEn && t.lang === 'en') return false;
      return true;
    });
  }

  function liked() {
    var c = count(), f = Z.vault.get('favorite', {});
    var list = filterLang(Z.api.TRACKS.slice());
    list.sort(function (a, b) { return score(b) - score(a); });
    function score(t) {
      return (c[t.id] || 0) * 2 + (f[t.id] ? 4 : 0) + (t.vip ? 1 : 0);
    }
    var out = [], seen = {};
    for (var i = 0; i < list.length && out.length < 12; i++) {
      if (!seen[list[i].id]) { seen[list[i].id] = 1; out.push(list[i]); }
    }
    return out;
  }

  /* 猜你喜欢的说明文案 */
  function hint() {
    var c = count(), best = null, n = 0;
    for (var id in c) if (c[id] > n) { n = c[id]; best = id; }
    if (!best) return '按热度为你挑选';
    var t = Z.api.byId(best);
    return t ? '因为你听过《' + t.name + '》' : '按热度为你挑选';
  }

  var R = {
    daily: daily,
    liked: liked,
    hint: hint,
    count: count,
    addHistory: function (t) {
      if (!t) return;
      var h = Z.vault.get('history', []);
      h.unshift({ id: t.id, at: Date.now() });
      if (h.length > 400) h.length = 400;
      Z.vault.set('history', h);
    },
    isFav: function (id) { return !!Z.vault.get('favorite', {})[id]; },
    toggleFav: function (t) {
      if (!t) return false;
      var f = Z.vault.get('favorite', {});
      if (f[t.id]) delete f[t.id]; else f[t.id] = Date.now();
      Z.vault.set('favorite', f);
      return !!f[t.id];
    },
    reset: function () {
      Z.vault.set('history', []);
      Z.vault.set('favorite', {});
    },
    dayKey: dayKey
  };
  Z.recommend = R;
})(window);
