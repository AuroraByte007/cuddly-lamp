/* shortcuts.js —— 快捷键 + 遥控器按键
 * 组合键存在 settings.dat（加密），设置面板可逐条重录
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};
  var D = document;

  var DEF = {
    play: 'Space', prev: 'Alt+ArrowLeft', next: 'Alt+ArrowRight',
    search: 'Ctrl+K', fav: 'L', official: 'D', full: 'F', mode: 'M', mini: 'Ctrl+M'
  };
  var LABEL = {
    play: '载入 / 停止', prev: '上一首', next: '下一首', search: '搜索',
    fav: '收藏', official: '官方页', full: '沉浸页', mode: '切换模式', mini: '收起播放条'
  };

  function map() {
    var s = Z.vault.getSetting('keys', {});
    var o = {};
    for (var k in DEF) o[k] = s[k] || DEF[k];
    return o;
  }
  function get(k) { return map()[k]; }
  function set(k, combo) {
    var s = Z.vault.getSetting('keys', {});
    s[k] = combo;
    Z.vault.setSetting('keys', s);
  }

  function match(combo, e) {
    var p = String(combo).split('+'), key = p.pop();
    var need = { ctrl: p.indexOf('Ctrl') > -1, alt: p.indexOf('Alt') > -1, shift: p.indexOf('Shift') > -1 };
    if (!!e.ctrlKey !== need.ctrl || !!e.altKey !== need.alt || !!e.shiftKey !== need.shift) return false;
    var k = e.key === ' ' ? 'Space' : (e.key.length === 1 ? e.key.toLowerCase() : e.key);
    return k.toLowerCase() === (key.length === 1 ? key.toLowerCase() : key);
  }

  function render() {
    var box = D.getElementById('scList');
    if (!box) return;
    var m = map(), h = '';
    for (var k in DEF) {
      h += '<div class="row"><span>' + LABEL[k] + '</span>' +
        '<button class="kk" data-key="' + k + '">' + m[k] + '</button></div>';
    }
    box.innerHTML = h;
  }

  /* 点击 kk 进入录制态，按下组合键后写入 */
  function bindRecorder() {
    D.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('[data-key]');
      if (!b) return;
      [].forEach.call(D.querySelectorAll('.kk'), function (x) { x.classList.remove('rec'); });
      b.classList.add('rec');
      b.textContent = '按下组合键…';
      var once = function (ev) {
        if (['Control', 'Alt', 'Shift', 'Meta'].indexOf(ev.key) > -1) return;
        ev.preventDefault();
        ev.stopPropagation();
        var parts = [];
        if (ev.ctrlKey) parts.push('Ctrl');
        if (ev.altKey) parts.push('Alt');
        if (ev.shiftKey) parts.push('Shift');
        parts.push(ev.key === ' ' ? 'Space' : ev.key);
        var combo = parts.join('+');
        set(b.getAttribute('data-key'), combo);
        b.textContent = combo;
        b.classList.remove('rec');
        D.removeEventListener('keydown', once, true);
        Z.ui.toast('已设置 ' + LABEL[b.getAttribute('data-key')]);
      };
      D.addEventListener('keydown', once, true);
    });
  }

  /* 注册全局按键：handlers 形如 { play: fn, next: fn, ... } */
  function bind(handlers) {
    D.addEventListener('keydown', function (e) {
      var tag = (e.target.tagName || '').toUpperCase();
      if ((tag === 'INPUT' || tag === 'TEXTAREA') && e.key !== 'Escape') return;
      if (e.key === 'Escape') {
        ['drawer', 'loginMask', 'redeemMask', 'imm'].forEach(function (id) {
          var n = D.getElementById(id);
          if (n) n.classList.remove('open');
          if (n && id === 'loginMask') n.classList.remove('show');
          if (n && id === 'redeemMask') n.classList.remove('show');
          if (n && id === 'imm') n.classList.remove('show');
          if (n && id === 'drawer') n.classList.remove('open');
        });
        return;
      }
      var m = map();
      for (var k in m) {
        if (handlers[k] && match(m[k], e)) { e.preventDefault(); handlers[k](); return; }
      }
      /* 遥控器方向键补充：上下切歌 */
      if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        e.preventDefault();
        if (handlers[e.key === 'ArrowUp' ? 'next' : 'prev']) handlers[e.key === 'ArrowUp' ? 'next' : 'prev']();
      }
    });
  }

  Z.shortcuts = { DEF: DEF, LABEL: LABEL, map: map, get: get, set: set, match: match, render: render, bind: bind, bindRecorder: bindRecorder };
})(window);
