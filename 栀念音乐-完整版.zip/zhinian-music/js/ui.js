/* ui.js —— 只做渲染与轻交互，不写入任何新样式
 * 用到的 class 全部来自 style.css 现有定义（card / chip / row / toast ...）
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};
  var D = document;

  function el(id) { return D.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function fmt(ms) {
    if (!ms || !isFinite(ms)) return '00:00';
    var s = Math.floor(ms / 1000), m = Math.floor(s / 60), r = s % 60;
    return (m < 10 ? '0' : '') + m + ':' + (r < 10 ? '0' : '') + r;
  }
  function toast(t) {
    var x = el('toast');
    if (!x) return;
    x.textContent = t;
    x.classList.add('show');
    clearTimeout(toast.tm);
    toast.tm = setTimeout(function () { x.classList.remove('show'); }, 1900);
  }

  function card(t, opts) {
    var vip = Z.api.isVipArtist(t), unlocked = Z.auth && Z.auth.isVip();
    var badge = vip ? (unlocked ? 'VIP·已解锁' : 'VIP') : '网易云';
    var data = ' data-id="' + esc(t.id) + '"';
    return '<div class="card"' + data + '>' +
      '<div class="card-cover">' +
      (t.pic ? '<img src="' + esc(t.pic) + '" alt="" loading="lazy" data-pic="' + esc(t.pic) + '">'
        : '<div class="cover-fallback">栀念</div>') +
      '<span class="badge">' + badge + '</span></div>' +
      '<div class="card-body"><div class="card-title">' + esc(t.name) + '</div>' +
      '<div class="card-sub">' + esc(t.artist || '佚名') + ' · ' + fmt(t.dur) + '</div></div>' +
      '<div class="card-actions"><button class="btn-icon" data-act="official" title="去官方页面">↗</button></div></div>';
  }

  /* 封面优先用本地缓存（离线也能显示），失败退回网络图 */
  function hydrateCovers() {
    var imgs = D.querySelectorAll('[data-pic]');
    [].forEach.call(imgs, function (img) {
      var url = img.getAttribute('data-pic');
      if (!url || img.getAttribute('data-hit')) return;
      Z.cache.getURL(url).then(function (u) {
        if (u) { img.src = u; img.setAttribute('data-hit', '1'); }
        else Z.cache.put(url, 'cover');
      }).catch(function () {});
    });
  }

  function paint() {
    var d = Z.recommend.daily(), l = Z.recommend.liked();
    el('dailyGrid').innerHTML = d.map(function (t) { return card(t); }).join('');
    el('likeGrid').innerHTML = l.map(function (t) { return card(t); }).join('');
    var now = new Date();
    el('todayDate').textContent = '· ' + (now.getMonth() + 1) + '月' + now.getDate() + '日 · ' + d.length + ' 首';
    el('likeHint').textContent = Z.recommend.hint();
    tabs();
    hydrateCovers();
    cacheInfo();
  }

  function tabs() {
    var s = Z.vault.getSetting('on', { A: 1, B: 1, C: 1, D: 1, E: 1 });
    var cur = Z.player ? Z.player.state().ch : 'A';
    el('tabs').innerHTML = Z.api.CHANNELS.map(function (c) {
      var off = s[c.id] === 0 ? ' off' : '';
      return '<button class="chip' + (cur === c.id ? ' on' : '') + off + '" data-ch="' + c.id + '">' + c.name + '</button>';
    }).join('');
  }

  function theme(t) {
    var r = D.documentElement;
    if (t === 'light') {
      r.style.setProperty('--bg', '#F2F3F7'); r.style.setProperty('--panel', 'rgba(255,255,255,.62)');
      r.style.setProperty('--line', 'rgba(0,0,0,.1)'); r.style.setProperty('--txt', '#1B1D22');
      r.style.setProperty('--txt2', '#5A6272'); r.style.setProperty('--txt3', '#8A91A0');
      r.style.setProperty('--brand', '#7C6BF5');
    } else if (t === 'purple') {
      r.style.setProperty('--bg', '#14101F'); r.style.setProperty('--brand', '#A78BFA');
      r.style.setProperty('--panel', 'rgba(255,255,255,.06)'); r.style.setProperty('--line', 'rgba(255,255,255,.12)');
      r.style.setProperty('--txt', '#E7E9EF'); r.style.setProperty('--txt2', '#9AA0AE'); r.style.setProperty('--txt3', '#6E7480');
    } else {
      r.style.setProperty('--bg', '#0E0F13'); r.style.setProperty('--panel', 'rgba(255,255,255,.06)');
      r.style.setProperty('--line', 'rgba(255,255,255,.12)'); r.style.setProperty('--txt', '#E7E9EF');
      r.style.setProperty('--txt2', '#9AA0AE'); r.style.setProperty('--txt3', '#6E7480');
      r.style.setProperty('--brand', '#7C6BF5');
    }
  }
  function nextTheme(cur) { return cur === 'dark' ? 'purple' : (cur === 'purple' ? 'light' : 'dark'); }

  function bar(track, extra) {
    el('plTitle').textContent = track ? track.name : '未选择歌曲';
    el('plArtist').textContent = (track ? (track.artist || '佚名') : '佚名') + (extra || '');
    var img = el('pcvImg'), fb = el('pcv');
    if (track && track.pic) {
      img.style.display = 'block';
      Z.cache.getURL(track.pic).then(function (u) { img.src = u || track.pic; }).catch(function () { img.src = track.pic; });
      Z.cache.put(track.pic, 'cover');
    } else img.style.display = 'none';
    el('tot').textContent = fmt(track ? track.dur : 0);
  }
  function progress(cur, total, pct) {
    el('cur').textContent = fmt(cur);
    el('tot').textContent = fmt(total);
    el('fill').style.width = Math.max(0, Math.min(100, pct)) + '%';
  }
  function immersion(track) {
    el('immTitle').textContent = track ? track.name : '未选择歌曲';
    el('immArtist').textContent = (track ? (track.artist || '佚名') : '佚名') + ' · 网易云';
    var img = el('immImg');
    if (track && track.pic) { img.style.display = 'block'; img.src = track.pic; } else img.style.display = 'none';
  }

  function cacheInfo() {
    var node = el('cacheInfo');
    if (!node) return;
    Z.cache.stats().then(function (s) {
      node.textContent = Z.cache.human(s.used) + ' / 500MB · ' + s.count + ' 项';
      var p = el('cacheBar');
      if (p) p.style.width = s.percent.toFixed(1) + '%';
    }).catch(function () {});
  }

  function offline(on) {
    var b = el('offBar');
    if (b) b.classList.toggle('show', !on);
  }

  Z.ui = {
    el: el, esc: esc, fmt: fmt, toast: toast, card: card,
    paint: paint, tabs: tabs, theme: theme, nextTheme: nextTheme,
    bar: bar, progress: progress, immersion: immersion,
    cacheInfo: cacheInfo, offline: offline, hydrateCovers: hydrateCovers
  };
})(window);
