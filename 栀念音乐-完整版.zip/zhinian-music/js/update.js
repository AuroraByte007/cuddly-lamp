/* update.js —— 版本检查（只提示，不强制、不自动刷新）
 * 读取同目录 library/update-manifest.json：
 *   {version, updateTime, changelog, downloadUrl, updateType, enableCheck}
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};

  function ver(v) {
    return String(v || '0').split('.').map(function (x) { return parseInt(x, 10) || 0; });
  }
  function gt(a, b) {
    var x = ver(a), y = ver(b);
    for (var i = 0; i < Math.max(x.length, y.length); i++) {
      var p = x[i] || 0, q = y[i] || 0;
      if (p > q) return true;
      if (p < q) return false;
    }
    return false;
  }

  function check(quiet) {
    if (Z.vault.getSetting('noUpdate', 0)) return Promise.resolve(null);
    return fetch('./library/update-manifest.json', { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (m) {
        if (!m || !m.enableCheck) return null;
        if (!gt(m.version, Z.VERSION)) { if (!quiet) Z.ui.toast('已是最新版本 ' + Z.VERSION); return null; }
        var line = '发现新版本 ' + m.version + (m.changelog ? '：' + m.changelog : '');
        Z.ui.toast(line);
        return m;
      })
      .catch(function () { if (!quiet) Z.ui.toast('版本清单读取失败'); return null; });
  }

  Z.update = { check: check, gt: gt };
})(window);
