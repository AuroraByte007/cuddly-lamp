/* vault.js —— 用户数据层
 * 结构对标 user-data/ 下的 5 个文件：
 *   profile.dat / favorite.dat / history.dat / settings.dat / meta.json
 * 写：全部经 ZN.cipher 加密后落 IndexedDB；读：解密回对象
 * 兼容：可导出成 .dat（base64 密文）供你手动替换 user-data/ 内文件；
 *       启动时会尝试读取 user-data/*.dat 作为初始种子（http 服务下有效）
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};
  var DB = 'zn_vault', STORE = 'docs', KEY = 'root';
  var SECTIONS = ['profile', 'favorite', 'history', 'settings'];
  var DEFAULTS = {
    profile: { phone: '', name: '', loginAt: 0, vipExpire: 0 },
    favorite: {}, history: [], settings: {}
  };
  var SECRET = 'znyy.local.vault.v1';  /* 口令固定派生：放弃口令模式，换取免输入 */
  var mem = null, dbp = null, ready = false;

  function open() {
    if (dbp) return dbp;
    dbp = new Promise(function (res, rej) {
      var r = w.indexedDB && w.indexedDB.open(DB, 1);
      if (!r) { rej(new Error('no indexedDB')); return; }
      r.onupgradeneeded = function () { r.result.createObjectStore(STORE); };
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
    });
    return dbp;
  }
  function idb(mode, fn) {
    return open().then(function (db) {
      return new Promise(function (res, rej) {
        var tx = db.transaction(STORE, mode), st = tx.objectStore(STORE);
        var req = fn(st);
        var out = req && req.result;
        req.onsuccess = function () { out = req.result; };
        tx.oncomplete = function () { res(out); };
        tx.onerror = function () { rej(tx.error); };
      });
    });
  }

  function baseDoc() {
    var d = {};
    SECTIONS.forEach(function (s) { d[s] = JSON.parse(JSON.stringify(DEFAULTS[s] || {})); });
    return d;
  }
  function merge(doc) {
    var d = baseDoc();
    if (doc && typeof doc === 'object') {
      SECTIONS.forEach(function (s) {
        if (doc[s] && typeof doc[s] === 'object') d[s] = doc[s];
      });
      if (Array.isArray(doc.history)) d.history = doc.history;
    }
    return d;
  }

  function seed() {
    /* user-data/*.dat 作为初始种子（有文件就读，读不到就跳过） */
    var files = SECTIONS.map(function (s) { return { s: s, f: './user-data/' + s + '.dat' }; });
    files.forEach(function (x) {
      fetch(x.f).then(function (r) { return r.ok ? r.text() : ''; }).then(function (t) {
        if (!t || t.trim().length < 8) return;
        try {
          var v = JSON.parse(Z.cipher.decrypt(t.trim(), SECRET));
          if (mem[s] === undefined) return;
          mem[x.s] = v; persist();
        } catch (e) { /* 种子无法解密就忽略 */ }
      }).catch(function () {});
    });
  }

  function persist() { return idb('readwrite', function (st) { st.put(Z.cipher.encrypt(JSON.stringify(mem), SECRET), KEY); }); }

  var V = {
    init: function () {
      if (ready) return Promise.resolve(V.all());
      /* IndexedDB 在隐私模式 / 部分 WebView 里会一直挂起，1.5 秒无响应即退化为会话内存储 */
      var timer = new Promise(function (res) {
        setTimeout(function () { res(null); }, 1500);
      });
      return Promise.race([idb('readwrite', function (st) { st.get(KEY); }), timer]).then(function (c) {
        var doc = null;
        if (typeof c === 'string' && c) { try { doc = JSON.parse(Z.cipher.decrypt(c, SECRET)); } catch (e) { doc = null; } }
        mem = merge(doc);
        ready = true;
        seed();
        return V.all();
      }).catch(function () {
        /* 无 IndexedDB 时退化为内存态，本次会话可用 */
        mem = mem || baseDoc(); ready = true;
        return V.all();
      });
    },
    all: function () { return mem || baseDoc(); },
    get: function (s, def) {
      if (!mem) mem = baseDoc();
      var v = mem[s];
      if (v === undefined) { mem[s] = def === undefined ? JSON.parse(JSON.stringify(DEFAULTS[s] || {})) : def; v = mem[s]; }
      return v;
    },
    set: function (s, v) {
      if (!mem) mem = baseDoc();
      mem[s] = v; return persist();
    },
    update: function (s, fn) {
      var v = V.get(s); fn(v); return V.set(s, v);
    },
    /* 导出成与 user-data/ 一致的文件内容 */
    exportFiles: function () {
      var out = {}, meta = { v: 1, iv: 'CBC-8', cipher: 'zn-feistel-64', key: 'derived', time: Date.now() };
      SECTIONS.forEach(function (s) {
        out[s + '.dat'] = Z.cipher.encrypt(JSON.stringify(V.get(s)), SECRET);
      });
      out['meta.json'] = JSON.stringify(meta, null, 2);
      return out;
    },
    importFiles: function (obj) {
      var n = 0;
      SECTIONS.forEach(function (s) {
        var t = obj[s + '.dat'];
        if (!t) return;
        try { mem[s] = JSON.parse(Z.cipher.decrypt(String(t).trim(), SECRET)); n++; } catch (e) {}
      });
      return persist().then(function () { return n; });
    },
    /* 设置项快捷读写（存在 settings.dat 内） */
    getSetting: function (k, def) {
      var s = V.get('settings');
      return s[k] === undefined ? def : s[k];
    },
    setSetting: function (k, v) {
      var s = V.get('settings');
      s[k] = v;
      return V.set('settings', s);
    },
    clear: function () { mem = baseDoc(); return persist(); }
  };
  Z.vault = V;
})(window);
