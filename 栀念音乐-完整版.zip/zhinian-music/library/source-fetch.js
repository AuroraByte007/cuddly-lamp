/* source-fetch.js —— 通道可达性探测（可选加载，不进主流程）
 * 用法：ZN.probe.check('https://music.163.com/outchain/player?...')
 * 原理：用隐藏 iframe 载入，8 秒内触发 load 视为可达；跨域无法读内部内容，只判断连通性
 */
(function (w) {
  'use strict';
  var Z = w.ZN = w.ZN || {};
  Z.probe = {
    timeout: 8000,
    check: function (url) {
      return new Promise(function (res) {
        var f = document.createElement('iframe');
        f.style.cssText = 'position:absolute;left:-9999px;width:1px;height:1px;opacity:0';
        var done = false;
        function fin(v) { if (done) return; done = true; f.remove(); res(v); }
        f.onload = function () { fin(true); };
        document.body.appendChild(f);
        f.src = url;
        setTimeout(function () { fin(false); }, Z.probe.timeout);
      });
    },
    checkJSON: function (url) {
      return fetch(url, { cache: 'no-store' }).then(function (r) { return r.ok; }).catch(function () { return false; });
    }
  };
})(window);
